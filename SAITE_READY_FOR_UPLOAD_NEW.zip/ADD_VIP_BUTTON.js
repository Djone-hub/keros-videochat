// 📤 ДОБАВЛЕНИЕ КНОПКИ ЗАГРУЗКИ VIP МОДОВ
// Добавьте этот скрипт в вашу админ панель

function addVipUploadButton() {
    // Находим форму загрузки обычных модов
    const modForm = document.querySelector('form') || document.querySelector('.upload-form');
    
    if (!modForm) {
        console.log('Форма загрузки модов не найдена');
        return;
    }
    
    // Проверяем есть ли уже кнопка VIP
    if (modForm.querySelector('.vip-upload-section')) {
        console.log('Кнопка VIP загрузки уже есть');
        return;
    }
    
    // Создаем VIP секцию
    const vipSection = document.createElement('div');
    vipSection.className = 'vip-upload-section';
    vipSection.innerHTML = `
        <div style="margin: 20px 0; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 10px; border: 1px solid #4c63d2;">
            <h4 style="color: white; margin: 0 0 15px 0;">📤 ЗАГРУЗКА VIP МОДОВ</h4>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                <div>
                    <label style="color: white; display: block; margin-bottom: 5px; font-weight: bold;">Выберите VIP мод:</label>
                    <select id="vipModSelect" style="width: 100%; padding: 8px; border: none; border-radius: 5px; background: rgba(255,255,255,0.1); color: white;">
                        <option value="">Выберите VIP мод...</option>
                    </select>
                </div>
                
                <div>
                    <label style="color: white; display: block; margin-bottom: 5px; font-weight: bold;">Файл (.zip, .htm, .html):</label>
                    <input type="file" id="vipFileInput" accept=".zip,.htm,.html,.rar,.7z" style="width: 100%; padding: 8px; border: none; border-radius: 5px; background: rgba(255,255,255,0.1); color: white;">
                </div>
            </div>
            
            <button id="uploadVipBtn" onclick="uploadVipMod()" style="background: linear-gradient(45deg, #ff6b6b, #ee5a24); color: white; padding: 12px 30px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; font-weight: bold; width: 100%; transition: all 0.3s ease;">
                📤 Загрузить VIP мод
            </button>
            
            <div id="vipUploadProgress" style="display: none; margin-top: 15px;">
                <div style="background: rgba(255,255,255,0.2); border-radius: 5px; padding: 2px;">
                    <div id="vipProgressFill" style="height: 20px; background: linear-gradient(90deg, #28a745, #20c997); border-radius: 3px; width: 0%; transition: width 0.3s ease;"></div>
                </div>
                <p id="vipProgressText" style="color: white; text-align: center; margin: 5px 0 0 0; font-size: 14px;">0%</p>
            </div>
            
            <div id="vipUploadMessage" style="margin-top: 10px; padding: 10px; border-radius: 5px; display: none;"></div>
        </div>
    `;
    
    // Вставляем перед формой загрузки
    modForm.parentNode.insertBefore(vipSection, modForm);
    
    // Загружаем VIP моды
    loadVipMods();
    
    console.log('✅ Кнопка загрузки VIP модов добавлена!');
}

// Глобальные переменные
let vipMods = [];
let userToken = null;

// Загрузка VIP модов
async function loadVipMods() {
    try {
        userToken = localStorage.getItem('supabase.auth.token');
        if (!userToken) {
            showVipMessage('Пожалуйста, войдите в систему', 'error');
            return;
        }
        
        const SUPABASE_URL = localStorage.getItem('supabase.url') || 'https://ВАШ_ПРОЕКТ.supabase.co';
        const SUPABASE_ANON_KEY = localStorage.getItem('supabase.anon_key') || 'ВАШ_ANON_КЛЮЧ';
        
        const response = await fetch(`${SUPABASE_URL}/rest/v1/mods?select=id,name,file_path,download_url,is_private,category&or=(is_private.eq.true,category.eq.vip_mods)`, {
            headers: {
                'Authorization': `Bearer ${userToken}`,
                'apikey': SUPABASE_ANON_KEY
            }
        });
        
        if (!response.ok) throw new Error('Ошибка загрузки VIP модов');
        
        vipMods = await response.json();
        
        const select = document.getElementById('vipModSelect');
        select.innerHTML = '<option value="">Выберите VIP мод...</option>';
        
        vipMods.forEach(mod => {
            const option = document.createElement('option');
            option.value = mod.id;
            option.textContent = `${mod.name} (${mod.file_path ? '✅ есть файл' : '❌ нет файла'})`;
            select.appendChild(option);
        });
        
    } catch (error) {
        console.error('Ошибка:', error);
        showVipMessage('Ошибка загрузки VIP модов: ' + error.message, 'error');
    }
}

// Загрузка VIP мода
async function uploadVipMod() {
    const modId = document.getElementById('vipModSelect').value;
    const fileInput = document.getElementById('vipFileInput');
    const file = fileInput.files[0];
    
    if (!modId || !file) {
        showVipMessage('Выберите VIP мод и файл', 'error');
        return;
    }
    
    const selectedMod = vipMods.find(m => m.id === modId);
    if (!selectedMod) {
        showVipMessage('VIP мод не найден', 'error');
        return;
    }
    
    const uploadBtn = document.getElementById('uploadVipBtn');
    const progress = document.getElementById('vipUploadProgress');
    const progressFill = document.getElementById('vipProgressFill');
    const progressText = document.getElementById('vipProgressText');
    
    uploadBtn.disabled = true;
    uploadBtn.textContent = '⏳ Загрузка...';
    progress.style.display = 'block';
    
    try {
        const SUPABASE_URL = localStorage.getItem('supabase.url') || 'https://ВАШ_ПРОЕКТ.supabase.co';
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('modId', modId);
        formData.append('modName', selectedMod.name);
        
        const xhr = new XMLHttpRequest();
        
        // Отслеживание прогресса
        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                progressFill.style.width = percentComplete + '%';
                progressText.textContent = Math.round(percentComplete) + '%';
            }
        });
        
        xhr.addEventListener('load', async () => {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                if (response.success) {
                    showVipMessage(`✅ ${response.message}`, 'success');
                    await loadVipMods();
                    document.getElementById('vipFileInput').value = '';
                } else {
                    showVipMessage(`❌ ${response.error}`, 'error');
                }
            } else {
                const error = JSON.parse(xhr.responseText);
                showVipMessage(`❌ ${error.error}`, 'error');
            }
            
            uploadBtn.disabled = false;
            uploadBtn.textContent = '📤 Загрузить VIP мод';
            progress.style.display = 'none';
        });
        
        xhr.addEventListener('error', () => {
            showVipMessage('❌ Ошибка сети при загрузке файла', 'error');
            uploadBtn.disabled = false;
            uploadBtn.textContent = '📤 Загрузить VIP мод';
            progress.style.display = 'none';
        });
        
        xhr.open('POST', `${SUPABASE_URL}/functions/v1/upload-vip-mod`);
        xhr.setRequestHeader('Authorization', `Bearer ${userToken}`);
        xhr.send(formData);
        
    } catch (error) {
        console.error('Ошибка:', error);
        showVipMessage('❌ Ошибка загрузки: ' + error.message, 'error');
        uploadBtn.disabled = false;
        uploadBtn.textContent = '📤 Загрузить VIP мод';
        progress.style.display = 'none';
    }
}

// Показ сообщений
function showVipMessage(text, type) {
    const message = document.getElementById('vipUploadMessage');
    message.textContent = text;
    message.className = type === 'success' ? 
        'background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;' :
        'background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;';
    message.style.display = 'block';
    
    setTimeout(() => {
        message.style.display = 'none';
    }, 5000);
}

// Автоматический запуск
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        addVipUploadButton();
    }, 1000);
});

// Экспорт функций
window.addVipUploadButton = addVipUploadButton;
