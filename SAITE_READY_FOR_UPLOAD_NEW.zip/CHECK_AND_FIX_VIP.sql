-- ========================================
-- ПРОВЕРКА И ИСПРАВЛЕНИЕ VIP МОДОВ
-- Выполните в Supabase SQL Editor
-- ========================================

-- Сначала проверяем что у нас есть
SELECT '=== ТЕКУЩИЕ VIP МОДЫ ===' as info;
SELECT 
    id, 
    name, 
    file_path, 
    download_url, 
    is_private, 
    category,
    CASE 
        WHEN file_path IS NOT NULL THEN '✅ Файл в Storage'
        WHEN download_url IS NOT NULL THEN '🔗 Внешняя ссылка'
        ELSE '❌ Нет файла'
    END as status
FROM mods 
WHERE is_private = true OR category = 'vip_mods'
ORDER BY created_at DESC;

-- Проверяем существует ли bucket
SELECT '=== ПРОВЕРКА STORAGE BUCKET ===' as info;
SELECT * FROM storage.buckets WHERE id = 'private-mods';

-- Если есть моды без файлов, создаем тестовые
DO $$
BEGIN
    -- Проверяем есть ли моды без file_path
    IF EXISTS (
        SELECT 1 FROM mods 
        WHERE (is_private = true OR category = 'vip_mods') 
        AND file_path IS NULL
        LIMIT 1
    ) THEN
        RAISE NOTICE '🔧 Найдены моды без файлов - создаем тестовые пути...';
        
        -- Обновляем тестовые моды с путями
        UPDATE mods 
        SET file_path = 'vip-mods/' || 
            CASE name
                WHEN 'тест вип' THEN 'test-vip.htm'
                WHEN 'Ёлка' THEN 'elka.htm'
                WHEN 'СОСНОВКА вип' THEN 'sosnovka.htm'
                ELSE 'unknown.htm'
            END
        WHERE (is_private = true OR category = 'vip_mods') 
        AND file_path IS NULL;
        
        RAISE NOTICE '✅ Тестовые пути созданы для модов!';
    END IF;
END $$;

-- Показываем результат
SELECT '=== РЕЗУЛЬТАТ ОБНОВЛЕНИЯ ===' as info;
SELECT 
    id, 
    name, 
    file_path, 
    download_url, 
    is_private, 
    category,
    CASE 
        WHEN file_path IS NOT NULL THEN '✅ Файл в Storage'
        WHEN download_url IS NOT NULL THEN '🔗 Внешняя ссылка'
        ELSE '❌ Нет файла'
    END as status
FROM mods 
WHERE is_private = true OR category = 'vip_mods'
ORDER BY created_at DESC;

-- Инструкция по загрузке файлов
SELECT '=== ИНСТРУКЦИЯ ПО ЗАГРУЗКЕ ФАЙЛОВ ===' as info;
SELECT '1. Откройте admin-upload-vip.html' as step1;
SELECT '2. Войдите как администратор' as step2;
SELECT '3. Выберите мод и загрузите соответствующий файл' as step3;
SELECT '4. После загрузки статус изменится на ✅ Файл в Storage' as step4;
