-- ========================================
-- ЗАЩИТА VIP МОДОВ - SQL СКРИПТ
-- Выполните в Supabase SQL Editor
-- ========================================

CREATE TABLE IF NOT EXISTS public.download_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token TEXT UNIQUE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    mod_id UUID REFERENCES mods(id) ON DELETE CASCADE NOT NULL,
    external_url TEXT NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    used_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_download_tokens_token ON public.download_tokens(token);
CREATE INDEX IF NOT EXISTS idx_download_tokens_user_id ON public.download_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_download_tokens_mod_id ON public.download_tokens(mod_id);
CREATE INDEX IF NOT EXISTS idx_download_tokens_expires_at ON public.download_tokens(expires_at);

ALTER TABLE public.download_tokens ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their own tokens" ON public.download_tokens;
DROP POLICY IF EXISTS "Service role can manage tokens" ON public.download_tokens;
CREATE POLICY "Users can view their own tokens" ON public.download_tokens FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Service role can manage tokens" ON public.download_tokens FOR ALL USING (true);

CREATE OR REPLACE FUNCTION public.cleanup_expired_download_tokens()
RETURNS void AS $$
BEGIN
    DELETE FROM public.download_tokens WHERE expires_at < NOW() OR used_at IS NOT NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TABLE IF NOT EXISTS public.download_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    mod_id UUID NOT NULL REFERENCES mods(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    mod_name TEXT NOT NULL,
    is_vip_mod BOOLEAN DEFAULT false,
    download_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_download_logs_mod_id ON download_logs(mod_id);
CREATE INDEX IF NOT EXISTS idx_download_logs_user_id ON download_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_download_logs_created_at ON download_logs(created_at);

ALTER TABLE download_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own download logs" ON download_logs;
DROP POLICY IF EXISTS "Admins can view all download logs" ON download_logs;
DROP POLICY IF EXISTS "Allow download log insertion" ON download_logs;

CREATE POLICY "Users can view own download logs" ON download_logs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all download logs" ON download_logs FOR SELECT USING (EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role IN ('admin', 'admin_senior', 'owner')));
CREATE POLICY "Allow download log insertion" ON download_logs FOR INSERT WITH CHECK (true);

ALTER TABLE mods ADD COLUMN IF NOT EXISTS last_downloaded TIMESTAMP WITH TIME ZONE;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'download_tokens') THEN
        RAISE NOTICE '✅ Таблица download_tokens создана!';
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'download_logs') THEN
        RAISE NOTICE '✅ Таблица download_logs создана!';
    END IF;
    RAISE NOTICE '🎉 Все таблицы успешно созданы!';
END $$;

-- ========================================
-- 8. ОБНОВЛЕНИЕ VIP МОДОВ (Ёлка и СОСНОВКА)
-- ========================================

-- Обновите ссылки на ваши файлы (Яндекс Диск, ShareMods и т.д.)
-- ЗАМЕНИТЕ ССЫЛКИ НА ВАШИ!

UPDATE mods 
SET download_url = 'https://disk.yandex.ru/d/ВАША_ССЫЛКА_НА_ЁЛКУ'
WHERE name LIKE '%Ёлка%' AND (download_url IS NULL OR download_url = '');

UPDATE mods 
SET download_url = 'https://disk.yandex.ru/d/ВАША_ССЫЛКА_НА_СОСНОВКУ'
WHERE name LIKE '%СОСНОВКА%' AND (download_url IS NULL OR download_url = '');

-- Если файлы в Supabase Storage (bucket private-mods), используйте file_path:
-- UPDATE mods SET file_path = 'vip-mods/Ёлка.htm' WHERE name LIKE '%Ёлка%' AND (file_path IS NULL OR file_path = '');
-- UPDATE mods SET file_path = 'vip-mods/СОСНОВКА.htm' WHERE name LIKE '%СОСНОВКА%' AND (file_path IS NULL OR file_path = '');

-- ========================================
-- 9. ПРОВЕРКА РЕЗУЛЬТАТА
-- ========================================

-- Показать все VIP моды и их ссылки
SELECT 
    id, 
    name, 
    file_path, 
    download_url, 
    category, 
    is_private,
    CASE 
        WHEN download_url IS NOT NULL THEN '✅ Внешняя ссылка'
        WHEN file_path IS NOT NULL THEN '✅ Файл в Storage'
        ELSE '❌ Нет файла'
    END as status
FROM mods 
WHERE is_private = true OR category = 'vip_mods'
ORDER BY created_at DESC;

-- ========================================
-- ГОТОВО!
-- ========================================
-- Теперь выполните в терминале:
-- cd H:\KEROS_MODS_2025\SAITE_READY_FOR_UPLOAD\supabase\functions
-- supabase functions deploy get-vip-download-link
-- supabase functions deploy download-external-file
