# 🚀 РУКОВОДСТВО ПО РАЗВЕРТЫВАНИЮ VIP ЗАЩИТЫ

## 📋 ПОРЯДОК ДЕЙСТВИЙ:

### 1️⃣ НАСТРОЙКА БАЗЫ ДАННЫХ

Выполните SQL скрипты в Supabase Dashboard → SQL Editor:

```sql
1. ENHANCED_VIP_PROTECTION.sql
2. SETUP_VIP_STORAGE.sql
```

### 2️⃣ РАЗВЕРТЫВАНИЕ EDGE FUNCTIONS

```bash
cd H:\KEROS_MODS_2025\SAITE_READY_FOR_UPLOAD\supabase\functions

supabase functions deploy upload-vip-mod
supabase functions deploy get-vip-secure-download  
supabase functions deploy download-vip-secure
```

### 3️⃣ ЗАГРУЗКА VIP ФАЙЛОВ

1. Откройте `admin-upload-vip.html`
2. Войдите как администратор
3. Загрузите файлы:
   - Ёлка.htm
   - СОСНОВКА.htm
   - Другие VIP моды

### 4️⃣ НАСТРОЙКА САЙТА

JavaScript код уже обновлен в `script.js`!

### 5️⃣ ПРОВЕРКА РАБОТЫ

1. Зайдите на сайт как VIP пользователь
2. Найдите VIP мод (Ёлка, СОСНОВКА)
3. Нажмите "Скачать"
4. Должна появиться защищенная ссылка

---

## 🔧 НАСТРОЙКИ:

### Замените домен в функциях:

В `get-vip-secure-download/index.ts`:
```typescript
const ALLOWED_DOMAINS = ['vash-sait.com', 'www.vash-sait.com']
```

### Настройте HTML форму:

В `admin-upload-vip.html`:
```javascript
const SUPABASE_URL = 'https://ВАШ_ПРОЕКТ.supabase.co'
const SUPABASE_ANON_KEY = 'ВАШ_ANON_КЛЮЧ'
```

---

## ✅ ПРОВЕРКА:

### SQL запросы для проверки:

```sql
-- Проверить загруженные файлы
SELECT id, name, file_path, download_url, is_private, category
FROM mods 
WHERE is_private = true OR category = 'vip_mods'
ORDER BY created_at DESC;

-- Проверить токены
SELECT token, user_id, mod_id, created_at, expires_at, is_blocked
FROM vip_download_tokens
ORDER BY created_at DESC;

-- Проверить нарушения
SELECT violation_type, user_ip, detected_at, action_taken
FROM security_violations
ORDER BY detected_at DESC;
```

---

## 🛡️ РЕЗУЛЬТАТ:

✅ VIP моды хранятся в Supabase Storage  
✅ Защищенные ссылки с привязкой к IP  
✅ Автоматическая блокировка при передаче ссылок  
✅ Уведомления админов о нарушениях  
✅ Полный контроль доступа к VIP контенту  

**Система готова к использованию!** 🎉
