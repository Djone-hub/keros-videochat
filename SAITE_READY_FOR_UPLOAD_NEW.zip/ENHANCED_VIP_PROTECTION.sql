-- ========================================
-- УСИЛЕННАЯ ЗАЩИТА VIP МОДОВ v2.0
-- Выполните в Supabase SQL Editor
-- ========================================

-- Таблица для усиленных токенов защиты
CREATE TABLE IF NOT EXISTS public.vip_download_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token TEXT UNIQUE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    mod_id UUID REFERENCES mods(id) ON DELETE CASCADE NOT NULL,
    external_url TEXT NOT NULL,
    
    -- Защитные поля
    user_ip TEXT NOT NULL,
    user_agent TEXT NOT NULL,
    referer_domain TEXT,
    session_id TEXT,
    
    -- Временные метки
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used_at TIMESTAMP WITH TIME ZONE,
    last_accessed_at TIMESTAMP WITH TIME ZONE,
    access_count INTEGER DEFAULT 0,
    
    -- Статус безопасности
    is_blocked BOOLEAN DEFAULT FALSE,
    block_reason TEXT,
    security_violations INTEGER DEFAULT 0,
    
    -- Уникальность (без WHERE в constraint)
    CONSTRAINT unique_user_mod_active UNIQUE (user_id, mod_id, is_blocked)
);

-- Индексы для быстрой проверки
CREATE INDEX IF NOT EXISTS idx_vip_tokens_token ON public.vip_download_tokens(token);
CREATE INDEX IF NOT EXISTS idx_vip_tokens_user_mod ON public.vip_download_tokens(user_id, mod_id);
CREATE INDEX IF NOT EXISTS idx_vip_tokens_ip ON public.vip_download_tokens(user_ip);
CREATE INDEX IF NOT EXISTS idx_vip_tokens_expires ON public.vip_download_tokens(expires_at);
CREATE INDEX IF NOT EXISTS idx_vip_tokens_blocked ON public.vip_download_tokens(is_blocked, created_at);

-- Уникальный индекс только для активных токенов
CREATE UNIQUE INDEX IF NOT EXISTS idx_vip_tokens_unique_active 
ON public.vip_download_tokens(user_id, mod_id) 
WHERE is_blocked = FALSE AND used_at IS NULL;

-- Таблица логов нарушений безопасности
CREATE TABLE IF NOT EXISTS public.security_violations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    token_id UUID REFERENCES vip_download_tokens(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    mod_id UUID REFERENCES mods(id) ON DELETE CASCADE NOT NULL,
    
    -- Тип нарушения
    violation_type TEXT NOT NULL CHECK (violation_type IN (
        'IP_MISMATCH',           -- IP адрес не совпадает
        'REFERER_MISMATCH',      -- Реферер не с вашего сайта
        'MULTIPLE_IPS',          -- Доступ с разных IP
        'TOKEN_SHARING',         -- Попытка передачи токена
        'EXPIRED_ACCESS',        -- Доступ после истечения
        'BOTS_DETECTED',         -- Обнаружен бот
        'SUSPICIOUS_PATTERN'     -- Подозрительная активность
    )),
    
    -- Детали нарушения
    user_ip TEXT NOT NULL,
    user_agent TEXT,
    referer TEXT,
    detected_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Действия
    action_taken TEXT NOT NULL CHECK (action_taken IN (
        'BLOCKED_TOKEN',         -- Токен заблокирован
        'USER_WARNED',           -- Пользователю предупреждение
        'ADMIN_NOTIFIED',        -- Админы уведомлены
        'LOGGED_ONLY'           -- Только залогировано
    )),
    
    -- Дополнительная информация
    details JSONB,
    admin_notified BOOLEAN DEFAULT FALSE,
    admin_notified_at TIMESTAMP WITH TIME ZONE
);

-- Индексы для нарушений
CREATE INDEX IF NOT EXISTS idx_security_violations_user ON public.security_violations(user_id, detected_at);
CREATE INDEX IF NOT EXISTS idx_security_violations_type ON public.security_violations(violation_type, detected_at);
CREATE INDEX IF NOT EXISTS idx_security_violations_token ON public.security_violations(token_id);

-- Включаем RLS
ALTER TABLE public.vip_download_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.security_violations ENABLE ROW LEVEL SECURITY;

-- Политики для токенов
DROP POLICY IF EXISTS "Users can view their own vip tokens" ON public.vip_download_tokens;
DROP POLICY IF EXISTS "Service role full access vip tokens" ON public.vip_download_tokens;
CREATE POLICY "Users can view their own vip tokens" ON public.vip_download_tokens FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Service role full access vip tokens" ON public.vip_download_tokens FOR ALL USING (true);

-- Политики для нарушений
DROP POLICY IF EXISTS "Users can view their own violations" ON public.security_violations;
DROP POLICY IF EXISTS "Admins can view all violations" ON public.security_violations;
DROP POLICY IF EXISTS "Service role full access violations" ON public.security_violations;
CREATE POLICY "Users can view their own violations" ON public.security_violations FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all violations" ON public.security_violations FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM profiles 
        WHERE profiles.id = auth.uid() 
        AND profiles.role IN ('admin', 'admin_senior', 'owner')
    )
);
CREATE POLICY "Service role full access violations" ON public.security_violations FOR ALL USING (true);

-- Функция для автоматической очистки старых токенов
CREATE OR REPLACE FUNCTION public.cleanup_expired_vip_tokens()
RETURNS void AS $$
BEGIN
    -- Удаляем токены старше 24 часов
    DELETE FROM public.vip_download_tokens 
    WHERE created_at < NOW() - INTERVAL '24 hours';
    
    -- Удаляем нарушения старше 7 дней
    DELETE FROM public.security_violations 
    WHERE detected_at < NOW() - INTERVAL '7 days';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Функция для проверки безопасности токена
CREATE OR REPLACE FUNCTION public.check_vip_token_security(
    p_token TEXT,
    p_user_ip TEXT,
    p_user_agent TEXT,
    p_referer TEXT DEFAULT NULL
)
RETURNS TABLE(
    is_valid BOOLEAN,
    is_blocked BOOLEAN,
    violation_type TEXT,
    block_reason TEXT
) AS $$
DECLARE
    token_record RECORD;
    violation_detected BOOLEAN := FALSE;
    violation_type_val TEXT;
    block_reason_val TEXT;
    referer_domain TEXT;
BEGIN
    -- Получаем запись токена
    SELECT * INTO token_record
    FROM public.vip_download_tokens
    WHERE token = p_token;
    
    -- Проверяем существование токена
    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, TRUE, 'TOKEN_NOT_FOUND', 'Токен не найден';
        RETURN;
    END IF;
    
    -- Проверяем блокировку
    IF token_record.is_blocked THEN
        RETURN QUERY SELECT FALSE, TRUE, 'TOKEN_BLOCKED', COALESCE(token_record.block_reason, 'Токен заблокирован');
        RETURN;
    END IF;
    
    -- Проверяем истечение
    IF token_record.expires_at < NOW() THEN
        UPDATE public.vip_download_tokens 
        SET is_blocked = TRUE, block_reason = 'TOKEN_EXPIRED'
        WHERE id = token_record.id;
        
        -- Логируем нарушение
        INSERT INTO public.security_violations (
            token_id, user_id, mod_id, violation_type, user_ip, user_agent, referer, action_taken
        ) VALUES (
            token_record.id, token_record.user_id, token_record.mod_id, 'EXPIRED_ACCESS', 
            p_user_ip, p_user_agent, p_referer, 'BLOCKED_TOKEN'
        );
        
        RETURN QUERY SELECT FALSE, TRUE, 'TOKEN_EXPIRED', 'Токен истек';
        RETURN;
    END IF;
    
    -- Проверяем IP адрес
    IF token_record.user_ip != p_user_ip THEN
        violation_detected := TRUE;
        violation_type_val := 'IP_MISMATCH';
        block_reason_val := 'IP адрес не совпадает с исходным';
    END IF;
    
    -- Проверяем реферер
    IF p_referer IS NOT NULL THEN
        -- Извлекаем домен из реферера
        SELECT regexp_replace(p_referer, '^https?://([^/]+).*', '\1') INTO referer_domain;
        
        -- Здесь нужно указать домен вашего сайта
        IF referer_domain NOT LIKE '%your-domain.com%' AND referer_domain NOT LIKE '%localhost%' THEN
            violation_detected := TRUE;
            violation_type_val := COALESCE(violation_type_val, 'REFERER_MISMATCH');
            block_reason_val := COALESCE(block_reason_val, 'Доступ разрешен только с сайта');
        END IF;
    END IF;
    
    -- Если обнаружено нарушение
    IF violation_detected THEN
        -- Блокируем токен
        UPDATE public.vip_download_tokens 
        SET is_blocked = TRUE, 
            block_reason = block_reason_val,
            security_violations = security_violations + 1
        WHERE id = token_record.id;
        
        -- Логируем нарушение
        INSERT INTO public.security_violations (
            token_id, user_id, mod_id, violation_type, user_ip, user_agent, referer, action_taken
        ) VALUES (
            token_record.id, token_record.user_id, token_record.mod_id, violation_type_val, 
            p_user_ip, p_user_agent, p_referer, 'BLOCKED_TOKEN'
        );
        
        RETURN QUERY SELECT FALSE, TRUE, violation_type_val, block_reason_val;
        RETURN;
    END IF;
    
    -- Обновляем время последнего доступа
    UPDATE public.vip_download_tokens 
    SET last_accessed_at = NOW(),
        access_count = access_count + 1
    WHERE id = token_record.id;
    
    -- Все проверки пройдены
    RETURN QUERY SELECT TRUE, FALSE, NULL, NULL;
    RETURN;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Проверка результата
DO $$ BEGIN
    RAISE NOTICE '✅ Усиленная защита VIP модов создана!';
    RAISE NOTICE '🛡️ Функции безопасности активированы!';
    RAISE NOTICE '📊 Таблицы для мониторинга нарушений готовы!';
END $$;
