// 🔧 ИСПРАВЛЕНИЕ СУЩЕСТВУЮЩЕЙ ФОРМЫ ЗАГРУЗКИ МОДОВ
// Добавьте этот скрипт в вашу админ панель

// Ищем форму загрузки модов
function fixExistingModUpload() {
    // Находим все формы с полями для загрузки модов
    const modForms = document.querySelectorAll('input[type="file"], input[placeholder*="мод"], input[placeholder*="мода"]');
    
    if (modForms.length === 0) {
        console.log('Формы загрузки модов не найдены');
        return;
    }
    
    modForms.forEach(form => {
        // Находим родительскую форму
        const parentForm = form.closest('form') || form.closest('.form-group');
        if (!parentForm) return;
        
        // Проверяем есть ли уже кнопка загрузки
        if (!parentForm.querySelector('.upload-mod-btn')) {
            // Добавляем кнопку загрузки
            const uploadBtn = document.createElement('button');
            uploadBtn.type = 'button';
            uploadBtn.className = 'upload-mod-btn primary-btn';
            uploadBtn.innerHTML = '📤 Загрузить мод';
            uploadBtn.onclick = () => uploadModFile(form, parentForm);
            
            // Вставляем кнопку после формы
            parentForm.parentNode.insertBefore(uploadBtn, parentForm.nextSibling);
            
            console.log('Добавлена кнопка загрузки для формы:', parentForm);
        }
    });
}

// Функция загрузки файла мода
async function uploadModFile(fileInput, parentForm) {
    const file = fileInput.files[0];
    if (!file) {
        alert('Выберите файл для загрузки');
        return;
    }
    
    // Находим название мода
    const nameInput = parentForm.querySelector('input[placeholder*="Название"], input[name*="name"]') || 
                        parentForm.querySelector('input[id*="name"]');
    
    const modName = nameInput ? nameInput.value || nameInput.placeholder : 'Неизвестный мод';
    
    // Показываем прогресс
    const uploadBtn = parentForm.querySelector('.upload-mod-btn');
    const originalText = uploadBtn.innerHTML;
    uploadBtn.innerHTML = '⏳ Загрузка...';
    uploadBtn.disabled = true;
    
    try {
        // Получаем настройки Supabase
        const SUPABASE_URL = localStorage.getItem('supabase.url') || 'https://ВАШ_ПРОЕКТ.supabase.co';
        const SUPABASE_ANON_KEY = localStorage.getItem('supabase.anon_key') || 'ВАШ_ANON_КЛЮЧ';
        const userToken = localStorage.getItem('supabase.auth.token');
        
        if (!userToken) {
            alert('Сначала войдите в систему');
            return;
        }
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('modName', modName);
        formData.append('isVip', 'false'); // Обычный мод, не VIP
        
        const xhr = new XMLHttpRequest();
        
        // Отслеживание прогресса
        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                uploadBtn.innerHTML = `⏳ Загрузка ${Math.round(percentComplete)}%`;
            }
        });
        
        xhr.addEventListener('load', () => {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                if (response.success) {
                    alert(`✅ Мод "${modName}" успешно загружен!`);
                    // Очищаем поле файла
                    fileInput.value = '';
                } else {
                    alert(`❌ Ошибка загрузки: ${response.error}`);
                }
            } else {
                alert('❌ Ошибка сервера при загрузке');
            }
            
            uploadBtn.innerHTML = originalText;
            uploadBtn.disabled = false;
        });
        
        xhr.addEventListener('error', () => {
            alert('❌ Ошибка сети при загрузке');
            uploadBtn.innerHTML = originalText;
            uploadBtn.disabled = false;
        });
        
        xhr.open('POST', `${SUPABASE_URL}/functions/v1/upload-vip-mod`);
        xhr.setRequestHeader('Authorization', `Bearer ${userToken}`);
        xhr.send(formData);
        
    } catch (error) {
        console.error('Ошибка загрузки:', error);
        alert(`❌ Ошибка: ${error.message}`);
        uploadBtn.innerHTML = originalText;
        uploadBtn.disabled = false;
    }
}

// Добавляем стили если их нет
if (!document.getElementById('mod-upload-fix-styles')) {
    const styles = document.createElement('style');
    styles.id = 'mod-upload-fix-styles';
    styles.textContent = `
        .upload-mod-btn {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            margin-top: 10px;
            width: 100%;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(40, 167, 69, 0.3);
        }
        
        .upload-mod-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(40, 167, 69, 0.4);
        }
        
        .upload-mod-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .progress-info {
            margin-top: 10px;
            padding: 5px 10px;
            background: rgba(40, 167, 69, 0.1);
            border-radius: 3px;
            font-size: 12px;
        }
    `;
    document.head.appendChild(styles);
}

// Автоматический запуск при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        fixExistingModUpload();
    }, 2000);
});

// Экспорт функций
window.fixExistingModUpload = fixExistingModUpload;
window.uploadModFile = uploadModFile;
