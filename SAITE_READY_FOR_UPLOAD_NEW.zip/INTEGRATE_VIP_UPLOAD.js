// 📤 ИНТЕГРАЦИЯ ЗАГРУЗКИ VIP МОДОВ В СУЩЕСТВУЮЩУЮ АДМИН ПАНЕЛЬ
// Добавьте этот скрипт в вашу админ панель

// Функция для добавления кнопки загрузки VIP модов
function addVipUploadButton() {
    // Находим раздел управления модами
    const modsSection = document.querySelector('[data-section="mods"]') || 
                       document.querySelector('.admin-mods-section') ||
                       document.querySelector('#mods-management') ||
                       document.querySelector('.mods-container');
    
    if (!modsSection) {
        console.warn('Раздел модов не найден');
        return;
    }
    
    // Создаем контейнер для VIP загрузки
    const vipUploadContainer = document.createElement('div');
    vipUploadContainer.className = 'vip-upload-section';
    vipUploadContainer.innerHTML = `
        <div class="section-header">
            <h3>📤 Загрузка VIP модов</h3>
            <button class="toggle-btn" onclick="toggleVipUpload()">
                <span id="vipToggleIcon">▼</span> Показать форму
            </button>
        </div>
        
        <div id="vipUploadForm" class="vip-upload-form" style="display: none;">
            <div class="form-row">
                <div class="form-group">
                    <label for="vipModSelect">Выберите VIP мод:</label>
                    <select id="vipModSelect" class="admin-select">
                        <option value="">Загрузка модов...</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="vipFileInput">Файл (.zip, .htm, .html):</label>
                    <input type="file" id="vipFileInput" class="admin-input" accept=".zip,.htm,.html,.rar,.7z">
                </div>
                
                <button id="uploadVipBtn" class="admin-btn primary-btn" onclick="uploadVipMod()">
                    📤 Загрузить VIP мод
                </button>
            </div>
            
            <div id="vipUploadProgress" class="progress-container" style="display: none;">
                <div class="progress-bar">
                    <div class="progress-fill" id="vipProgressFill"></div>
                </div>
                <p id="vipProgressText">0%</p>
            </div>
            
            <div id="vipUploadMessage" class="admin-message"></div>
        </div>
    `;
    
    // Вставляем перед разделом модов
    modsSection.parentNode.insertBefore(vipUploadContainer, modsSection);
    
    // Добавляем стили
    if (!document.getElementById('vip-upload-styles')) {
        const styles = document.createElement('style');
        styles.id = 'vip-upload-styles';
        styles.textContent = `
            .vip-upload-section {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 20px;
                margin: 20px 0;
                border-radius: 10px;
                box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            }
            
            .section-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            }
            
            .section-header h3 {
                margin: 0;
                color: white;
            }
            
            .toggle-btn {
                background: rgba(255, 255, 255, 0.2);
                color: white;
                border: 1px solid rgba(255, 255, 255, 0.3);
                padding: 8px 15px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 14px;
                transition: all 0.3s ease;
            }
            
            .toggle-btn:hover {
                background: rgba(255, 255, 255, 0.3);
            }
            
            .vip-upload-form {
                background: rgba(255, 255, 255, 0.1);
                padding: 20px;
                border-radius: 8px;
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            
            .form-row {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-bottom: 20px;
            }
            
            .admin-select, .admin-input {
                width: 100%;
                padding: 12px;
                border: 2px solid rgba(255, 255, 255, 0.3);
                border-radius: 5px;
                font-size: 14px;
                background: rgba(255, 255, 255, 0.1);
                color: white;
                box-sizing: border-box;
            }
            
            .admin-select:focus, .admin-input:focus {
                outline: none;
                border-color: rgba(255, 255, 255, 0.6);
                box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.2);
            }
            
            .primary-btn {
                background: linear-gradient(45deg, #ff6b6b, #ee5a24);
                color: white;
                padding: 12px 30px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
                font-weight: bold;
                width: 100%;
                transition: all 0.3s ease;
                box-shadow: 0 4px 15px rgba(238, 90, 36, 0.3);
            }
            
            .primary-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(238, 90, 36, 0.4);
            }
            
            .primary-btn:disabled {
                background: #6c757d;
                cursor: not-allowed;
                transform: none;
                box-shadow: none;
            }
            
            .progress-container {
                margin-top: 20px;
            }
            
            .progress-bar {
                width: 100%;
                height: 20px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 10px;
                overflow: hidden;
            }
            
            .progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #28a745, #20c997);
                width: 0%;
                transition: width 0.3s ease;
            }
            
            .admin-message {
                padding: 15px;
                margin: 20px 0;
                border-radius: 5px;
                display: none;
                font-weight: 500;
            }
            
            .admin-message.success {
                background: rgba(40, 167, 69, 0.2);
                color: #28a745;
                border: 1px solid rgba(40, 167, 69, 0.3);
            }
            
            .admin-message.error {
                background: rgba(220, 53, 69, 0.2);
                color: #dc3545;
                border: 1px solid rgba(220, 53, 69, 0.3);
            }
        `;
        document.head.appendChild(styles);
    }
    
    // Загружаем моды и инициализируем функционал
    loadVipMods();
}

// Переключение видимости формы
function toggleVipUpload() {
    const form = document.getElementById('vipUploadForm');
    const icon = document.getElementById('vipToggleIcon');
    
    if (form.style.display === 'none') {
        form.style.display = 'block';
        icon.textContent = '▲';
    } else {
        form.style.display = 'none';
        icon.textContent = '▼';
    }
}

// Глобальные переменные
let vipMods = [];
let userToken = null;

// Загрузка VIP модов
async function loadVipMods() {
    try {
        userToken = localStorage.getItem('supabase.auth.token');
        if (!userToken) {
            showVipMessage('Пожалуйста, войдите в систему', 'error');
            return;
        }
        
        const SUPABASE_URL = localStorage.getItem('supabase.url') || 'https://ВАШ_ПРОЕКТ.supabase.co';
        const SUPABASE_ANON_KEY = localStorage.getItem('supabase.anon_key') || 'ВАШ_ANON_КЛЮЧ';
        
        const response = await fetch(`${SUPABASE_URL}/rest/v1/mods?select=id,name,file_path,download_url,is_private,category&or=(is_private.eq.true,category.eq.vip_mods)`, {
            headers: {
                'Authorization': `Bearer ${userToken}`,
                'apikey': SUPABASE_ANON_KEY
            }
        });
        
        if (!response.ok) throw new Error('Ошибка загрузки модов');
        
        vipMods = await response.json();
        
        const select = document.getElementById('vipModSelect');
        select.innerHTML = '<option value="">Выберите VIP мод...</option>';
        
        vipMods.forEach(mod => {
            const option = document.createElement('option');
            option.value = mod.id;
            option.textContent = `${mod.name} (${mod.file_path ? '✅ есть файл' : '❌ нет файла'})`;
            select.appendChild(option);
        });
        
    } catch (error) {
        console.error('Ошибка:', error);
        showVipMessage('Ошибка загрузки VIP модов: ' + error.message, 'error');
    }
}

// Загрузка файла
async function uploadVipMod() {
    const modId = document.getElementById('vipModSelect').value;
    const fileInput = document.getElementById('vipFileInput');
    const file = fileInput.files[0];
    
    if (!modId || !file) {
        showVipMessage('Выберите мод и файл', 'error');
        return;
    }
    
    const selectedMod = vipMods.find(m => m.id === modId);
    if (!selectedMod) {
        showVipMessage('Мод не найден', 'error');
        return;
    }
    
    const uploadBtn = document.getElementById('uploadVipBtn');
    const progress = document.getElementById('vipUploadProgress');
    const progressFill = document.getElementById('vipProgressFill');
    const progressText = document.getElementById('vipProgressText');
    
    uploadBtn.disabled = true;
    uploadBtn.textContent = '⏳ Загрузка...';
    progress.style.display = 'block';
    
    try {
        const SUPABASE_URL = localStorage.getItem('supabase.url') || 'https://ВАШ_ПРОЕКТ.supabase.co';
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('modId', modId);
        formData.append('modName', selectedMod.name);
        
        const xhr = new XMLHttpRequest();
        
        // Отслеживание прогресса
        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                progressFill.style.width = percentComplete + '%';
                progressText.textContent = Math.round(percentComplete) + '%';
            }
        });
        
        xhr.addEventListener('load', async () => {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                if (response.success) {
                    showVipMessage(`✅ ${response.message}`, 'success');
                    await loadVipMods(); // Перезагружаем список
                    document.getElementById('vipFileInput').value = ''; // Очищаем поле
                } else {
                    showVipMessage(`❌ ${response.error}`, 'error');
                }
            } else {
                const error = JSON.parse(xhr.responseText);
                showVipMessage(`❌ ${error.error}`, 'error');
            }
            
            uploadBtn.disabled = false;
            uploadBtn.textContent = '📤 Загрузить VIP мод';
            progress.style.display = 'none';
        });
        
        xhr.addEventListener('error', () => {
            showVipMessage('❌ Ошибка сети при загрузке файла', 'error');
            uploadBtn.disabled = false;
            uploadBtn.textContent = '📤 Загрузить VIP мод';
            progress.style.display = 'none';
        });
        
        xhr.open('POST', `${SUPABASE_URL}/functions/v1/upload-vip-mod`);
        xhr.setRequestHeader('Authorization', `Bearer ${userToken}`);
        xhr.send(formData);
        
    } catch (error) {
        console.error('Ошибка:', error);
        showVipMessage('❌ Ошибка загрузки: ' + error.message, 'error');
        uploadBtn.disabled = false;
        uploadBtn.textContent = '📤 Загрузить VIP мод';
        progress.style.display = 'none';
    }
}

// Показ сообщений
function showVipMessage(text, type) {
    const message = document.getElementById('vipUploadMessage');
    message.textContent = text;
    message.className = `admin-message ${type}`;
    message.style.display = 'block';
    
    setTimeout(() => {
        message.style.display = 'none';
    }, 5000);
}

// Автоматическое добавление при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Ждем загрузки админ панели
    setTimeout(() => {
        addVipUploadButton();
    }, 1000);
});

// Экспорт функций для глобального доступа
window.addVipUploadButton = addVipUploadButton;
window.uploadVipMod = uploadVipMod;
