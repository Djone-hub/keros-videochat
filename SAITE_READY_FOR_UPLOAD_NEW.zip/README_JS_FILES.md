# 📋 Рабочие файлы в js/

## 🗂️ **Основные модули системы**

### 🔐 **Аутентификация и безопасность**
- **auth-system.js** - система аутентификации пользователей
- **security.js** - безопасность и защита
- **password-eyes.js** - глаза для паролей (показать/скрыть)

### 🎵 **Мультимедиа**
- **background-music.js** - фоновая музыка
- **image-utils.js** - утилиты для работы с изображениями

### 🎨 **Интерфейс**
- **beautiful-scrollbar.js** - кастомные скроллбары
- **ui-modals.js** - модальные окна
- **modal-notifications.js** - модальные уведомления

### 📢 **Уведомления**
- **unified_ticker_ui.js** - бегущая строка
- **ticker_edit_functions.js** - функции бегущей строки

### 🛒 **Магазин и заказы**
- **shop-system.js** - система магазина
- **loadOrders-minimal.js** - заказы
- **order-management.js** - управление заказами

### 🎮 **Моды**
- **mods-system.js** - система модов
- **mods.js** - моды

### 👥 **Управление пользователями**
- **user-management.js** - управление пользователями
- **user-delete-manager.js** - удаление пользователей

### 🔧 **Утилиты и сервисы**
- **init.js** - инициализация системы
- **storage-utils.js** - локальное хранилище
- **supabaseClient.js** - клиент Supabase
- **retry_supabase_requests.js** - повторные запросы к Supabase

---

## 📁 **Структура папок**
```
📁 js/
├── 📄 22 рабочих файла (перечислены выше)
├── 📁 lib/ (библиотеки)
├── 📁 images/ (изображения)
└── 📁 unused_modules/ (неиспользуемые модули)
```

## 🔗 **Порядок подключения в index.html**
1. `supabaseClient.js` - клиент Supabase
2. `storage-utils.js` - утилиты хранилища
3. `image-utils.js` - утилиты изображений
4. `auth-system.js` - аутентификация
5. `ui-modals.js` - модальные окна
6. `background-music.js` - фоновая музыка
7. `mods.js` - моды
8. `mods-system.js` - система модов
9. `shop-system.js` - магазин
10. `vip-order-blocker-fixed.js` - VIP блокировщик
11. `user-management.js` - управление пользователями
12. `user-delete-manager.js` - удаление пользователей
13. `security.js` - безопасность
14. `script.js` - основной скрипт
15. `beautiful-scrollbar.js` - скроллбары
16. `admin-panel-fixed.js` - админ панель
17. `admin-panel-security.js` - безопасность админ панели
18. `retry_supabase_requests.js` - повторные запросы
19. `password-eyes.js` - глаза для паролей
20. `loadOrders-minimal.js` - заказы
21. `modal-notifications.js` - модальные уведомления
22. `order-management.js` - управление заказами
23. `init.js` - инициализация
24. `unified_ticker_ui.js` - бегущая строка
25. `ticker_edit_functions.js` - функции бегущей строки

---

## ⚠️ **Важные замечания**
- Все файлы работают в связке друг с другом
- Изменение порядка подключения может вызвать ошибки
- `unused_modules/` содержит старые версии файлов (не удалять до полного тестирования)
- Основной файл `script.js` находится в корне проекта

## 📅 **Обновлено:** 19.02.2026
## 🏷️ **Версия:** v1.165.0
