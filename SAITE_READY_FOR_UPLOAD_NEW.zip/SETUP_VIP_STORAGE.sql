-- ========================================
-- НАСТРОЙКА STORAGE ДЛЯ VIP МОДОВ
-- Выполните в Supabase SQL Editor
-- ========================================

-- Создаем bucket для VIP модов (если еще не создан)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'private-mods', 
    'private-mods', 
    false, -- Приватный bucket
    104857600, -- 100MB лимит
    ARRAY['text/html', 'application/zip', 'application/x-zip-compressed', 'application/octet-stream']
) ON CONFLICT (id) DO NOTHING;

-- Политики доступа для VIP модов
-- 1. VIP пользователи могут читать свои файлы
CREATE POLICY "VIP users can read their mods" ON storage.objects
FOR SELECT USING (
    bucket_id = 'private-mods' AND
    EXISTS (
        SELECT 1 FROM profiles p
        WHERE p.id = auth.uid()
        AND (
            p.is_vip = true OR 
            p.role IN ('vip', 'moderator', 'moderator_senior', 'admin', 'admin_senior', 'owner')
        )
        AND (p.vip_expires_at IS NULL OR p.vip_expires_at > NOW())
        AND p.is_banned = false
    )
);

-- 2. VIP пользователи могут скачивать файлы
CREATE POLICY "VIP users can download mods" ON storage.objects
FOR SELECT USING (
    bucket_id = 'private-mods' AND
    EXISTS (
        SELECT 1 FROM profiles p
        WHERE p.id = auth.uid()
        AND (
            p.is_vip = true OR 
            p.role IN ('vip', 'moderator', 'moderator_senior', 'admin', 'admin_senior', 'owner')
        )
        AND (p.vip_expires_at IS NULL OR p.vip_expires_at > NOW())
        AND p.is_banned = false
    )
);

-- 3. Админы могут загружать и управлять файлами
CREATE POLICY "Admins can manage VIP mods" ON storage.objects
FOR ALL USING (
    bucket_id = 'private-mods' AND
    EXISTS (
        SELECT 1 FROM profiles p
        WHERE p.id = auth.uid()
        AND p.role IN ('admin', 'admin_senior', 'owner')
    )
);

-- Проверка результата
DO $$
BEGIN
    RAISE NOTICE '✅ Storage bucket для VIP модов настроен!';
    RAISE NOTICE '📁 Название bucket: private-mods';
    RAISE NOTICE '🔒 Приватный доступ - только для VIP пользователей';
    RAISE NOTICE '👑 Админы могут загружать файлы';
END $$;
