# 🔧 Диагностика проблем подключения к Supabase

## Ошибка: `Failed to load resource: net::ERR_TIMED_OUT`

### ✅ Применённые исправления

1. **Добавлены повторные попытки подключения** (3 попытки через 2 секунды)
2. **Добавлен таймаут** (10 секунд)
3. **Добавлены обработчики сети** (`online`/`offline`)
4. **Добавлены уведомления** при проблемах с подключением

### 🔍 Проверка подключения

Откройте консоль браузера (F12) и выполните:

```javascript
// 1. Проверка доступности Supabase
fetch('https://gtixajbcfxwqrtsdxnif.supabase.co')
    .then(r => console.log('✅ Supabase доступен:', r.status))
    .catch(e => console.error('❌ Supabase недоступен:', e));

// 2. Проверка авторизации
const { data: { user }, error } = await window.supabase.auth.getUser();
console.log('👤 Пользователь:', user);
console.log('❌ Ошибка:', error);

// 3. Проверка подключения к базе данных
const { data, error: queryError } = await window.supabase
    .from('profiles')
    .select('id, email')
    .limit(1);

console.log('📦 Данные:', data);
console.log('❌ Ошибка запроса:', queryError);
```

### 🛠️ Возможные причины и решения

#### 1. Проблемы с интернет-соединением

**Проверка:**
```javascript
console.log('🌐 Статус сети:', navigator.onLine ? 'Онлайн' : 'Офлайн');
```

**Решение:**
- Проверьте подключение к интернету
- Перезагрузите роутер/модем
- Попробуйте другое соединение (Wi-Fi → мобильная сеть)

#### 2. Блокировка Supabase

**Причины:**
- Брандмауэр блокирует доступ
- Антивирус блокирует соединение
- Провайдер блокирует Supabase
- Корпоративная сеть ограничивает доступ

**Проверка:**
```javascript
// Проверка доступности порта
fetch('https://gtixajbcfxwqrtsdxnif.supabase.co:443')
    .then(r => console.log('✅ Порт 443 открыт'))
    .catch(e => console.error('❌ Порт 443 заблокирован:', e));
```

**Решение:**
- Отключите VPN/прокси (если есть)
- Добавьте Supabase в исключения брандмауэра
- Попробуйте открыть сайт в режиме инкогнито
- Проверьте с другого устройства/браузера

#### 3. Неверные учётные данные

**Проверка:**
```javascript
console.log('🔑 URL:', window.SUPABASE_URL || 'https://gtixajbcfxwqrtsdxnif.supabase.co');
console.log('🔑 Ключ:', window.SUPABASE_ANON_KEY?.substring(0, 20) + '...');
```

**Решение:**
- Проверьте файл `js/supabaseClient.js`
- Убедитесь, что ключ API правильный
- Проверьте, что проект Supabase активен

#### 4. Проблемы на стороне Supabase

**Проверка статуса:**
- Откройте https://status.supabase.com
- Проверьте Twitter @supabase

**Решение:**
- Подождите пока Supabase восстановит работу
- Используйте резервное копирование

### 📋 Логи для диагностики

Сохраните эти логи и отправьте разработчику:

```javascript
// Полная диагностика
async function diagnoseSupabase() {
    console.log('🔍 === ДИАГНОСТИКА SUPABASE ===');
    
    // 1. Статус сети
    console.log('🌐 Сеть:', navigator.onLine ? 'Онлайн' : 'Офлайн');
    
    // 2. Проверка CDN
    console.log('📦 Supabase CDN:', typeof window.supabase);
    
    // 3. Проверка клиента
    console.log('🔧 Клиент готов:', window.supabaseReady);
    
    // 4. Проверка авторизации
    try {
        const { data: { user }, error: authError } = await window.supabase.auth.getUser();
        console.log('👤 Авторизация:', user ? 'Успешна' : 'Не выполнена');
        if (authError) console.error('❌ Ошибка авторизации:', authError);
    } catch (e) {
        console.error('❌ Ошибка проверки авторизации:', e);
    }
    
    // 5. Проверка запроса
    try {
        const { data, error } = await window.supabase
            .from('profiles')
            .select('id')
            .limit(1);
        console.log('📦 Запрос:', error ? '❌ Ошибка' : '✅ Успешен');
        if (error) console.error('❌ Ошибка запроса:', error);
    } catch (e) {
        console.error('❌ Ошибка выполнения запроса:', e);
    }
    
    console.log('🔍 === КОНЕЦ ДИАГНОСТИКИ ===');
}

// Запустить диагностику
diagnoseSupabase();
```

### 🚀 Быстрые решения

#### 1. Перезагрузить страницу с очисткой кэша
```
Ctrl + F5 (Windows/Linux)
Cmd + Shift + R (Mac)
```

#### 2. Очистить localStorage и перезагрузить
```javascript
localStorage.clear();
sessionStorage.clear();
window.location.reload();
```

#### 3. Перезапустить Supabase клиент
```javascript
// В консоли выполните:
if (typeof initializeSupabase === 'function') {
    window.supabaseReady = false;
    initializeSupabase();
}
```

### 📞 Если ничего не помогло

1. **Сохраните логи** (выполните `diagnoseSupabase()`)
2. **Проверьте консоль браузера** на наличие других ошибок
3. **Попробуйте другой браузер** (Chrome, Firefox, Edge)
4. **Проверьте с другого устройства**
5. **Обратитесь к провайдеру** (возможно блокировка)

### 📊 Статистика подключений

Для отслеживания проблем добавьте мониторинг:

```javascript
// Счётчик ошибок подключения
let connectionErrors = 0;
const MAX_ERRORS = 5;

window.addEventListener('offline', () => {
    connectionErrors++;
    console.warn(`⚠️ Ошибка подключения (${connectionErrors}/${MAX_ERRORS})`);
    
    if (connectionErrors >= MAX_ERRORS) {
        showNotification('❌ Множественные ошибки подключения. Проверьте интернет.', 'error', 10000);
    }
});
```
