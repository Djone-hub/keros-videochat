# 🔐 Защита VIP модов от передачи ссылок

## 📋 Что было сделано

### 1. **Для файлов в Supabase Storage**
- ✅ Ссылки генерируются через `createSignedUrl()` 
- ✅ Уникальны для каждого пользователя
- ✅ Истекают через **60 секунд**
- ✅ Привязаны к сессии пользователя
- ✅ Нельзя передать другому пользователю

### 2. **Для внешних ссылок (ShareMods, Яндекс Диск и т.д.)**
- ✅ Генерируется уникальный токен доступа
- ✅ Токен сохраняется в таблице `download_tokens`
- ✅ Токен привязан к **конкретному пользователю** и **конкретному моду**
- ✅ Истекает через **5 минут**
- ✅ После использования токен **удаляется**
- ✅ Скачивание происходит через Edge Function `download-external-file`

## 🚀 Развёртывание

### Шаг 1: Создайте таблицу `download_tokens`

1. Откройте **Supabase Dashboard**
2. Перейдите в **SQL Editor**
3. Выполните SQL из файла `database/create_download_tokens_table.sql`

```sql
-- Скопируйте содержимое файла и выполните
```

### Шаг 2: Разверните Edge Function

```bash
# Перейдите в папку с функциями
cd supabase/functions

# Разверните функцию download-external-file
supabase functions deploy download-external-file

# Обновите функцию get-vip-download-link (если уже развёрнута)
supabase functions deploy get-vip-download-link
```

### Шаг 3: Проверьте работу

1. **Для обычного пользователя:**
   - Попробуйте скачать VIP мод
   - Должна появиться уникальная ссылка
   - Попробуйте открыть ссылку в режиме инкогнито - должна быть ошибка

2. **Для проверки токенов:**
   ```sql
   -- Посмотреть активные токены
   SELECT * FROM download_tokens 
   WHERE expires_at > NOW() 
   ORDER BY created_at DESC;
   
   -- Посмотреть использованные токены
   SELECT * FROM download_logs 
   ORDER BY created_at DESC 
   LIMIT 10;
   ```

## 🔒 Как это работает

### Supabase Storage
```
Пользователь → Edge Function → Проверка VIP → createSignedUrl() → Уникальная ссылка (60 сек)
```

### Внешние ссылки
```
Пользователь → Edge Function → Проверка VIP → Генерация токена → 
Сохранение в БД → Ссылка на /functions/v1/download-external-file?token=XXX →
Проверка токена → Перенаправление на ShareMods
```

## 📊 Мониторинг

### Логи скачиваний
```sql
-- Последние 10 скачиваний
SELECT 
    dl.created_at,
    dl.mod_name,
    p.username,
    p.email,
    dl.is_vip_mod
FROM download_logs dl
JOIN profiles p ON dl.user_id = p.id
ORDER BY dl.created_at DESC
LIMIT 10;
```

### Активные токены
```sql
-- Токены которые ещё действительны
SELECT 
    dt.token,
    p.username,
    m.name as mod_name,
    dt.expires_at,
    CASE 
        WHEN dt.expires_at < NOW() THEN 'Истек'
        ELSE 'Активен'
    END as status
FROM download_tokens dt
JOIN profiles p ON dt.user_id = p.id
JOIN mods m ON dt.mod_id = m.id
ORDER BY dt.created_at DESC;
```

## ⚠️ Важные замечания

1. **Внешние ссылки всё равно можно передать**
   - После перенаправления на ShareMods ссылка становится публичной
   - Но токен для доступа к Edge Function уникален и истекает через 5 минут

2. **Для полной защиты используйте Supabase Storage**
   - Файлы в Storage полностью защищены
   - Ссылки истекают через 60 секунд
   - Нельзя скачать без активной VIP подписки

3. **Автоматическая очистка**
   - Истекшие токены удаляются функцией `cleanup_expired_download_tokens()`
   - Рекомендуется настроить pg_cron для автоматической очистки раз в час

## 🎯 Результат

- ✅ **VIP моды в Storage**: Полностью защищены, ссылка на 60 секунд
- ✅ **Внешние ссылки**: Токен на 5 минут, привязан к пользователю
- ✅ **Логирование**: Все скачивания записываются в `download_logs`
- ✅ **Мониторинг**: Можно отследить кто и когда скачал
