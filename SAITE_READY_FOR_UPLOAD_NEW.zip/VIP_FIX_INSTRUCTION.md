# Инструкция по обновлению модов как VIP

## Проблема
После выдачи VIP статуса пользователю, VIP моды не появляются, потому что:
1. Моды не помечены как VIP (`is_private = false`)
2. VIP контейнеры удалялись из DOM вместо скрытия

## Решение

### 1. Исправления в коде (уже применены)

**Файл `js/auth-system.js` (строки 1001-1013):**
- Изменено: VIP элементы теперь **скрываются** вместо удаления
- Было: `vipCategories.remove()`
- Стало: `vipCategories.style.display = 'none'`

**Файл `script.js` (строки 12964-12973):**
- Добавлена автоматическая перезагрузка страницы через 3 секунды после выдачи VIP
- Это гарантирует корректную инициализацию всех VIP компонентов

### 2. Обновление существующих модов как VIP

Откройте консоль браузера (F12) и выполните:

```javascript
// Шаг 1: Проверить текущие моды
const { data: mods } = await window.supabase.from('mods').select('id, name, is_private, game_version');
console.log('📦 Все моды:', mods);

// Шаг 2: Обновить ВСЕ моды как VIP
await window.supabase.from('mods').update({ is_private: true });
console.log('✅ Все моды обновлены как VIP');

// Шаг 3: Проверить результат
const { data: updatedMods } = await window.supabase.from('mods').select('id, name, is_private');
console.log('✅ Обновлённые моды:', updatedMods);
```

**ИЛИ** обновить только конкретные моды:

```javascript
// Обновить конкретный мод по ID
await window.supabase.from('mods').update({ is_private: true }).eq('id', 'ID_МОДА');

// Обновить несколько модов по ID
await window.supabase.from('mods').update({ is_private: true }).in('id', ['ID_1', 'ID_2', 'ID_3']);
```

### 3. Выдача VIP статуса пользователю

1. Откройте админ-панель (пульсирующая кнопка в правом верхнем углу)
2. Перейдите в раздел "Пользователи"
3. Найдите нужного пользователя
4. Нажмите кнопку "💎" рядом с пользователем
5. Введите VIP пароль: `VIP2026KEROS`
6. Нажмите "Подтвердить"

**После этого:**
- Через 3 секунды страница автоматически перезагрузится
- После перезагрузки пользователь увидит:
  - Значок 💎 рядом с именем
  - Таймер обратного отсчёта VIP статуса
  - Кнопку "💎 VIP" в панели выбора игр
  - VIP категории модов
  - VIP моды (если они помечены как `is_private = true`)

### 4. Проверка работы

После перезагрузки страницы:

1. **Проверьте значок VIP:** В правом верхнем углу должен быть значок 💎 и таймер
2. **Проверьте кнопку VIP:** В панели выбора игр должна быть кнопка "💎 VIP"
3. **Нажмите на кнопку VIP:** Должны открыться VIP категории
4. **Выберите категорию:** Должны загрузиться VIP моды

### 5. Если моды не появляются

Проверьте, что моды помечены как VIP:

```javascript
// Проверить статус модов
const { data: mods } = await window.supabase.from('mods').select('id, name, is_private');
mods.forEach(mod => {
    console.log(`${mod.name}: is_private = ${mod.is_private}`);
});
```

Если `is_private = false`, обновите моды:

```javascript
await window.supabase.from('mods').update({ is_private: true });
```

## Итоговые изменения в файлах

### `js/auth-system.js`
```diff
- // Удаляем VIP кнопку
- const vipGameButton = document.querySelector('.game-btn[data-game="vip_mods"]');
- if (vipGameButton) vipGameButton.remove();
-
- // Удаляем VIP категории
- const vipCategories = document.getElementById('vip_modsCategories');
- if (vipCategories) vipCategories.remove();

+ // 🔧 ИСПРАВЛЕНИЕ: Не удаляем VIP кнопку, а только скрываем
+ const vipGameButton = document.querySelector('.game-btn[data-game="vip_mods"]');
+ if (vipGameButton) vipGameButton.style.display = 'none';
+
+ // 🔧 ИСПРАВЛЕНИЕ: Не удаляем VIP категории, а только скрываем
+ const vipCategories = document.getElementById('vip_modsCategories');
+ if (vipCategories) {
+     vipCategories.style.display = 'none';
+     console.log('💎 VIP категории скрыты (нет доступа):', profileToCheck);
+ }
```

### `script.js`
```diff
+ // 🔧 ИСПРАВЛЕНИЕ: Перезагружаем страницу через 3 секунды для применения VIP статуса
+ // Это гарантирует, что все компоненты (VIP кнопка, категории, моды) корректно инициализируются
+ showNotification('🔄 Страница будет перезагружена для применения VIP статуса...', 'info', 3000);
+ setTimeout(() => {
+     window.location.reload();
+ }, 3000);
```

### `js/admin-panel-fixed.js`
```diff
- // Если VIP статус активирован, загружаем VIP моды
- if (isVip && typeof loadModsByCategory === 'function') {
-     console.log('💎 Загружаем VIP моды после активации статуса');
-     await loadModsByCategory('vip_mods');
- }

+ // 🔧 ИСПРАВЛЕНИЕ: Если VIP статус активирован, переключаемся на VIP игру
+ if (isVip && typeof switchGameVersion === 'function') {
+     console.log('💎 Загружаем VIP моды после активации статуса');
+     await switchGameVersion('vip_mods', 'Все');
+ }
```

## Примечания

1. **Автоматическая перезагрузка** происходит только при выдаче VIP статуса
2. **При истечении VIP** моды скрываются автоматически без перезагрузки
3. **VIP моды** должны быть помечены флагом `is_private = true` в базе данных
