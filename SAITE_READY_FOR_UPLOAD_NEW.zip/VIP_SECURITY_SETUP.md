# 🛡️ УСИЛЕННАЯ ЗАЩИТА VIP МОДОВ v2.0

## 📋 ОБЗОР СИСТЕМЫ

Создана мощная система защиты VIP контента которая:

✅ **Генерирует уникальные ссылки** для каждого VIP пользователя  
✅ **Привязывает ссылки к IP адресу** пользователя  
✅ **Проверяет реферер** - доступ только с вашего сайта  
✅ **Отслеживает сессию** пользователя  
✅ **Блокирует при попытке передачи** ссылки  
✅ **Уведомляет админов** о нарушениях  
✅ **Логирует все нарушения** безопасности  

---

## 🚀 УСТАНОВКА

### 1. Выполните SQL скрипт

В Supabase Dashboard → SQL Editor выполните:
```
ENHANCED_VIP_PROTECTION.sql
```

### 2. Разверните Edge Functions

```bash
cd H:\KEROS_MODS_2025\SAITE_READY_FOR_UPLOAD\supabase\functions

supabase functions deploy get-vip-secure-download
supabase functions deploy download-vip-secure
```

Или создайте вручную в Supabase Dashboard → Edge Functions.

### 3. Настройте домен

В файле `get-vip-secure-download/index.ts` замените:
```typescript
const ALLOWED_DOMAINS = ['your-domain.com', 'localhost:3000', 'localhost:5173']
```

На ваши домены:
```typescript
const ALLOWED_DOMAINS = ['vash-sait.com', 'www.vash-sait.com']
```

---

## 🔧 ИСПОЛЬЗОВАНИЕ

### Для генерации защищенной ссылки:

**JavaScript код на сайте:**
```javascript
async function getVipDownloadLink(modId) {
  try {
    const response = await fetch(`${SUPABASE_URL}/functions/v1/get-vip-secure-download`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${userToken}`,
        'Content-Type': 'application/json',
        'Referer': 'https://vash-sait.com' // Важно!
      },
      body: JSON.stringify({ modId })
    })
    
    const data = await response.json()
    
    if (data.success) {
      console.log('🛡️ Защищенная ссылка:', data.secureUrl)
      console.log('⏰ Истекает через:', data.expiresInSeconds, 'секунд')
      
      // Перенаправляем пользователя
      window.location.href = data.secureUrl
    } else {
      alert('Ошибка: ' + data.error)
    }
  } catch (error) {
    console.error('Ошибка:', error)
  }
}
```

---

## 🚨 СИСТЕМА БЛОКИРОВКИ

### Автоматическая блокировка происходит при:

1. **IP MISMATCH** - IP адрес не совпадает с исходным
2. **REFERER_MISMATCH** - Доступ не с вашего сайта  
3. **TOKEN_SHARING** - Попытка передачи ссылки другому
4. **EXPIRED_ACCESS** - Попытка доступа после истечения
5. **MULTIPLE_IPS** - Доступ с разных IP адресов

### Что происходит при нарушении:

🔒 **Мгновенная блокировка** токена  
📊 **Логирование нарушения** в базу данных  
📧 **Уведомление всех админов** системы  
⚠️ **Пользователь получает сообщение** о блокировке  

---

## 📊 МОНИТОРИНГ

### Просмотр нарушений:

```sql
-- Все нарушения безопасности
SELECT 
    sv.violation_type,
    sv.user_ip,
    p.username,
    p.email,
    m.name as mod_name,
    sv.detected_at,
    sv.action_taken
FROM security_violations sv
JOIN profiles p ON sv.user_id = p.id  
JOIN mods m ON sv.mod_id = m.id
ORDER BY sv.detected_at DESC;

-- Активные токены
SELECT 
    vt.token,
    p.username,
    m.name as mod_name,
    vt.user_ip,
    vt.created_at,
    vt.expires_at,
    vt.access_count
FROM vip_download_tokens vt
JOIN profiles p ON vt.user_id = p.id
JOIN mods m ON vt.mod_id = m.id
WHERE vt.is_blocked = FALSE AND vt.used_at IS NULL
ORDER BY vt.created_at DESC;
```

---

## 🔄 ОБНОВЛЕНИЕ СУЩЕСТВУЮЩИХ МОДОВ

### Обновление JavaScript кода сайта:

Замените старые функции скачивания на новые:

```javascript
// Старый код (небезопасный):
async function getVipDownloadLink(modId) {
  // ... старая логика
}

// Новый код (безопасный):
async function getVipDownloadLink(modId) {
  // ... новая безопасная логика из примера выше
}
```

---

## ⚙️ НАСТРОЙКИ

### Время жизни токенов:

В `get-vip-secure-download/index.ts`:
```typescript
const expiresAt = new Date(Date.now() + 5 * 60 * 1000) // 5 минут
```

### Дополнительные домены:

```typescript
const ALLOWED_DOMAINS = [
  'vash-sait.com', 
  'www.vash-sait.com',
  'cdn.vash-sait.com',
  'localhost:3000' // для разработки
]
```

---

## 🛡️ ПРЕИМУЩЕСТВА СИСТЕМЫ

✅ **100% защита** от передачи ссылок  
✅ **Мгновенная блокировка** нарушителей  
✅ **Автоматические уведомления** админов  
✅ **Подробная статистика** нарушений  
✅ **Привязка к устройству** пользователя  
✅ **Проверка реферера** для защиты от ботов  
✅ **Одноразовые токены** для максимальной безопасности  

---

## 📞 ПОДДЕРЖКА

Если возникнут проблемы:

1. Проверьте логи в Supabase Dashboard → Edge Functions
2. Посмотрите таблицы `security_violations` и `vip_download_tokens`
3. Убедитесь что домен правильно настроен в `ALLOWED_DOMAINS`

**Система готова к использованию!** 🎉
