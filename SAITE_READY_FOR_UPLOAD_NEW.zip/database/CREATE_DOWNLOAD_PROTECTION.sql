-- ========================================
-- ЗАЩИТА VIP МОДОВ - ПОЛНЫЙ SQL СКРИПТ
-- Скопируйте и выполните в Supabase SQL Editor
-- ========================================

-- ========================================
-- 1. ТАБЛИЦА ДЛЯ ВРЕМЕННЫХ ТОКЕНОВ
-- ========================================

CREATE TABLE IF NOT EXISTS public.download_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token TEXT UNIQUE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    mod_id UUID REFERENCES mods(id) ON DELETE CASCADE NOT NULL,
    external_url TEXT NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    used_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT valid_token CHECK (length(token) > 0),
    CONSTRAINT valid_expires_at CHECK (expires_at > created_at)
);

-- Индексы
CREATE INDEX IF NOT EXISTS idx_download_tokens_token ON public.download_tokens(token);
CREATE INDEX IF NOT EXISTS idx_download_tokens_user_id ON public.download_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_download_tokens_mod_id ON public.download_tokens(mod_id);
CREATE INDEX IF NOT EXISTS idx_download_tokens_expires_at ON public.download_tokens(expires_at);

-- RLS
ALTER TABLE public.download_tokens ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their own tokens" ON public.download_tokens;
DROP POLICY IF EXISTS "Service role can manage tokens" ON public.download_tokens;

CREATE POLICY "Users can view their own tokens"
    ON public.download_tokens FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage tokens"
    ON public.download_tokens FOR ALL
    USING (true);

-- ========================================
-- 2. ФУНКЦИЯ ОЧИСТКИ ТОКЕНОВ
-- ========================================

CREATE OR REPLACE FUNCTION public.cleanup_expired_download_tokens()
RETURNS void AS $$
BEGIN
    DELETE FROM public.download_tokens
    WHERE expires_at < NOW() OR used_at IS NOT NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ========================================
-- 3. ТАБЛИЦА ЛОГОВ СКАЧИВАНИЙ
-- ========================================

CREATE TABLE IF NOT EXISTS public.download_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    mod_id UUID NOT NULL REFERENCES mods(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    mod_name TEXT NOT NULL,
    is_vip_mod BOOLEAN DEFAULT false,
    download_url TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_download_logs_mod_id ON download_logs(mod_id);
CREATE INDEX IF NOT EXISTS idx_download_logs_user_id ON download_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_download_logs_created_at ON download_logs(created_at);

ALTER TABLE download_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own download logs" ON download_logs;
DROP POLICY IF EXISTS "Admins can view all download logs" ON download_logs;
DROP POLICY IF EXISTS "Allow download log insertion" ON download_logs;

CREATE POLICY "Users can view own download logs" ON download_logs
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all download logs" ON download_logs
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE profiles.id = auth.uid() 
            AND profiles.role IN ('admin', 'admin_senior', 'owner')
        )
    );

CREATE POLICY "Allow download log insertion" ON download_logs
    FOR INSERT WITH CHECK (true);

-- ========================================
-- 4. ДОБАВЛЯЕМ КОЛОНКУ В MODS
-- ========================================

ALTER TABLE mods 
ADD COLUMN IF NOT EXISTS last_downloaded TIMESTAMP WITH TIME ZONE;

-- ========================================
-- 5. КОММЕНТАРИИ
-- ========================================

COMMENT ON TABLE public.download_tokens IS 'Временные токены для безопасного скачивания VIP модов';
COMMENT ON COLUMN public.download_tokens.token IS 'Уникальный токен доступа';
COMMENT ON COLUMN public.download_tokens.user_id IS 'ID пользователя';
COMMENT ON COLUMN public.download_tokens.mod_id IS 'ID мода';
COMMENT ON COLUMN public.download_tokens.external_url IS 'Внешняя ссылка';
COMMENT ON COLUMN public.download_tokens.expires_at IS 'Время истечения';

COMMENT ON TABLE public.download_logs IS 'Лог скачиваний модов';

-- ========================================
-- 6. ПРОВЕРКА
-- ========================================

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'download_tokens') THEN
        RAISE NOTICE '✅ Таблица download_tokens создана!';
    END IF;
    
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'download_logs') THEN
        RAISE NOTICE '✅ Таблица download_logs создана!';
    END IF;
    
    RAISE NOTICE '🎉 Все таблицы успешно созданы!';
END $$;

-- ========================================
-- 7. ПРОВЕРКА ДАННЫХ
-- ========================================

-- Посмотреть активные токены
-- SELECT * FROM download_tokens WHERE expires_at > NOW() ORDER BY created_at DESC LIMIT 10;

-- Посмотреть последние скачивания
-- SELECT * FROM download_logs ORDER BY created_at DESC LIMIT 10;

-- Очистить истекшие токены
-- SELECT public.cleanup_expired_download_tokens();
