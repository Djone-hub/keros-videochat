-- Таблица для хранения временных токенов скачивания внешних файлов
-- Выполните этот SQL в Supabase SQL Editor

CREATE TABLE IF NOT EXISTS public.download_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token TEXT UNIQUE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    mod_id UUID REFERENCES mods(id) ON DELETE CASCADE NOT NULL,
    external_url TEXT NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    used_at TIMESTAMP WITH TIME ZONE,
    
    -- Индексы для быстрого поиска
    CONSTRAINT valid_token CHECK (length(token) > 0),
    CONSTRAINT valid_expires_at CHECK (expires_at > created_at)
);

-- Индексы для производительности
CREATE INDEX IF NOT EXISTS idx_download_tokens_token ON public.download_tokens(token);
CREATE INDEX IF NOT EXISTS idx_download_tokens_user_id ON public.download_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_download_tokens_mod_id ON public.download_tokens(mod_id);
CREATE INDEX IF NOT EXISTS idx_download_tokens_expires_at ON public.download_tokens(expires_at);

-- Автоматическая очистка истекших токенов (раз в час)
CREATE OR REPLACE FUNCTION public.cleanup_expired_download_tokens()
RETURNS void AS $$
BEGIN
    DELETE FROM public.download_tokens
    WHERE expires_at < NOW() OR used_at IS NOT NULL;
END;
$$ LANGUAGE plpgsql;

-- Планировщик для очистки (если используете pg_cron)
-- SELECT cron.schedule('cleanup-download-tokens', '0 * * * *', 'SELECT public.cleanup_expired_download_tokens()');

-- RLS (Row Level Security)
ALTER TABLE public.download_tokens ENABLE ROW LEVEL SECURITY;

-- Токены видны только владельцу
CREATE POLICY "Users can view their own tokens"
    ON public.download_tokens
    FOR SELECT
    USING (auth.uid() = user_id);

-- Токены могут создавать только через Edge Function с service role
-- (RLS не применяется для service role ключа)

COMMENT ON TABLE public.download_tokens IS 'Временные токены для безопасного скачивания внешних файлов';
COMMENT ON COLUMN public.download_tokens.token IS 'Уникальный токен доступа';
COMMENT ON COLUMN public.download_tokens.user_id IS 'ID пользователя которому выдан токен';
COMMENT ON COLUMN public.download_tokens.mod_id IS 'ID мода который можно скачать';
COMMENT ON COLUMN public.download_tokens.external_url IS 'Внешняя ссылка на файл (ShareMods и т.д.)';
COMMENT ON COLUMN public.download_tokens.expires_at IS 'Время истечения токена';
COMMENT ON COLUMN public.download_tokens.used_at IS 'Время использования токена (NULL если не использован';
