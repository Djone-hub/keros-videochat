-- ========================================
-- ЗАЩИТА VIP МОДОВ - ТАБЛИЦА ТОКЕНОВ
-- Выполните этот SQL в Supabase SQL Editor
-- ========================================

-- Создаем таблицу для временных токенов скачивания
CREATE TABLE IF NOT EXISTS public.download_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token TEXT UNIQUE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    mod_id UUID REFERENCES mods(id) ON DELETE CASCADE NOT NULL,
    external_url TEXT NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    used_at TIMESTAMP WITH TIME ZONE,
    
    -- Проверки валидности
    CONSTRAINT valid_token CHECK (length(token) > 0),
    CONSTRAINT valid_expires_at CHECK (expires_at > created_at)
);

-- Создаем индексы для быстрого поиска
CREATE INDEX IF NOT EXISTS idx_download_tokens_token ON public.download_tokens(token);
CREATE INDEX IF NOT EXISTS idx_download_tokens_user_id ON public.download_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_download_tokens_mod_id ON public.download_tokens(mod_id);
CREATE INDEX IF NOT EXISTS idx_download_tokens_expires_at ON public.download_tokens(expires_at);

-- Включаем RLS (Row Level Security)
ALTER TABLE public.download_tokens ENABLE ROW LEVEL SECURITY;

-- Удаляем старые политики если они есть
DROP POLICY IF EXISTS "Users can view their own tokens" ON public.download_tokens;
DROP POLICY IF EXISTS "Service role can manage tokens" ON public.download_tokens;

-- Политика: Пользователи могут видеть только свои токены
CREATE POLICY "Users can view their own tokens"
    ON public.download_tokens
    FOR SELECT
    USING (auth.uid() = user_id);

-- Политика: Service role может управлять всеми токенами (для Edge Function)
CREATE POLICY "Service role can manage tokens"
    ON public.download_tokens
    FOR ALL
    USING (true);

-- ========================================
-- ФУНКЦИЯ ДЛЯ АВТОМАТИЧЕСКОЙ ОЧИСТКИ
-- ========================================

CREATE OR REPLACE FUNCTION public.cleanup_expired_download_tokens()
RETURNS void AS $$
BEGIN
    DELETE FROM public.download_tokens
    WHERE expires_at < NOW() OR used_at IS NOT NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ========================================
-- КОММЕНТАРИИ ДЛЯ ДОКУМЕНТАЦИИ
-- ========================================

COMMENT ON TABLE public.download_tokens IS 'Временные токены для безопасного скачивания VIP модов с внешних файлов (ShareMods, Яндекс Диск и т.д.)';
COMMENT ON COLUMN public.download_tokens.token IS 'Уникальный токен доступа (Base64 encoded)';
COMMENT ON COLUMN public.download_tokens.user_id IS 'ID пользователя которому выдан токен';
COMMENT ON COLUMN public.download_tokens.mod_id IS 'ID мода который можно скачать по токену';
COMMENT ON COLUMN public.download_tokens.external_url IS 'Внешняя ссылка на файл (ShareMods, Яндекс Диск и т.д.)';
COMMENT ON COLUMN public.download_tokens.expires_at IS 'Время истечения токена (5 минут после создания)';
COMMENT ON COLUMN public.download_tokens.created_at IS 'Время создания токена';
COMMENT ON COLUMN public.download_tokens.used_at IS 'Время использования токена (NULL если не использован)';

-- ========================================
-- ПРОВЕРКА СОЗДАНИЯ
-- ========================================

-- Проверяем что таблица создана
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'download_tokens') THEN
        RAISE NOTICE '✅ Таблица download_tokens успешно создана!';
    ELSE
        RAISE EXCEPTION '❌ Ошибка: Таблица download_tokens не создана!';
    END IF;
END $$;

-- ========================================
-- ИНСТРУКЦИЯ ПО ИСПОЛЬЗОВАНИЮ
-- ========================================

-- 1. Разверните Edge Function:
--    supabase functions deploy download-external-file
--    supabase functions deploy get-vip-download-link

-- 2. Проверьте работу:
--    SELECT * FROM download_tokens ORDER BY created_at DESC LIMIT 10;

-- 3. Для ручной очистки токенов:
--    SELECT public.cleanup_expired_download_tokens();
