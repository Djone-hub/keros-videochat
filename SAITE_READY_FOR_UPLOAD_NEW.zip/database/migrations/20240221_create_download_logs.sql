-- Создаем таблицу для логирования скачиваний модов
CREATE TABLE IF NOT EXISTS download_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    mod_id UUID NOT NULL REFERENCES mods(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    mod_name TEXT NOT NULL,
    is_vip_mod BOOLEAN DEFAULT false,
    download_url TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Создаем индексы для быстрого поиска
CREATE INDEX IF NOT EXISTS idx_download_logs_mod_id ON download_logs(mod_id);
CREATE INDEX IF NOT EXISTS idx_download_logs_user_id ON download_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_download_logs_created_at ON download_logs(created_at);

-- Добавляем колонку в таблицу модов для отслеживания последнего скачивания
ALTER TABLE mods 
ADD COLUMN IF NOT EXISTS last_downloaded TIMESTAMP WITH TIME ZONE;

-- Включаем RLS для таблицы логов
ALTER TABLE download_logs ENABLE ROW LEVEL SECURITY;

-- Удаляем существующие политики если они есть (для безопасного обновления)
DROP POLICY IF EXISTS "Users can view own download logs" ON download_logs;
DROP POLICY IF EXISTS "Admins can view all download logs" ON download_logs;
DROP POLICY IF EXISTS "Allow download log insertion" ON download_logs;

-- Политика для пользователей - могут видеть только свои логи
CREATE POLICY "Users can view own download logs" ON download_logs
    FOR SELECT USING (auth.uid() = user_id);

-- Политика для админов - могут видеть все логи
CREATE POLICY "Admins can view all download logs" ON download_logs
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE profiles.id = auth.uid() 
            AND profiles.role IN ('admin', 'admin_senior', 'owner')
        )
    );

-- Политика для вставки логов (через Edge Function)
CREATE POLICY "Allow download log insertion" ON download_logs
    FOR INSERT WITH CHECK (true);
