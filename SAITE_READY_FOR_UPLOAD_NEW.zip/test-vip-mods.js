// Тестовая функция для проверки VIP модов
// Добавьте этот код в script.js для тестирования

window.testVipMods = async function() {
    try {
        console.log('🧪 Тестирование VIP модов...');
        
        // Получаем текущего пользователя
        const { data: { user } } = await window.supabase.auth.getUser();
        if (!user) {
            console.error('❌ Пользователь не авторизован');
            return;
        }
        
        // Получаем профиль пользователя
        const { data: profile } = await window.supabase
            .from('profiles')
            .select('*')
            .eq('id', user.id)
            .single();
            
        console.log('👤 Профиль пользователя:', profile);
        
        // Тестируем функцию updateModsForVipChange
        if (typeof window.updateModsForVipChange === 'function') {
            console.log('✅ Функция updateModsForVipChange найдена');
            
            // Тестируем с VIP=true
            console.log('🔄 Тестируем с VIP=true');
            await window.updateModsForVipChange(user.id, true);
            
            // Ждем 2 секунды
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Тестируем с VIP=false
            console.log('🔄 Тестируем с VIP=false');
            await window.updateModsForVipChange(user.id, false);
            
        } else {
            console.error('❌ Функция updateModsForVipChange не найдена');
        }
        
        // Проверяем карточки модов
        const modCards = document.querySelectorAll('.mod-card');
        console.log(`📦 Найдено карточек модов: ${modCards.length}`);
        
        const vipModCards = document.querySelectorAll('.mod-card.vip-mod');
        console.log(`💎 Найдено VIP карточек модов: ${vipModCards.length}`);
        
        vipModCards.forEach((card, index) => {
            const downloadBtn = card.querySelector('button[onclick*="handleDownloadClick"]');
            console.log(`VIP мод ${index + 1}:`, {
                display: card.style.display,
                buttonDisabled: downloadBtn?.disabled,
                buttonText: downloadBtn?.textContent
            });
        });
        
    } catch (error) {
        console.error('❌ Ошибка тестирования:', error);
    }
};

console.log('🧪 Функция testVipMods() добавлена. Вызовите testVipMods() в консоли для тестирования');
